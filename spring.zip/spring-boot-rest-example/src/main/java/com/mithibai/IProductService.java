package com.mithibai;
import java.util.List;
public interface IProductService 
{
List<Product> findAll();
}
